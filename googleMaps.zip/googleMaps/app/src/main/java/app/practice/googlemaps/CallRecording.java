package app.practice.googlemaps;

import static android.content.ContentValues.TAG;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.Service;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.icu.text.AlphabeticIndex;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;

import com.google.gson.Gson;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

public class CallRecording extends AppCompatActivity {
    ArrayList<String> mArrayList;
    MediaPlayer mPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call_recording);
        startService(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopService(this);
    }

    private void startService(Context context) {
        ContextCompat.startForegroundService(context, new Intent(context, TService.class)); //ForegroundService
    }

    private void stopService(Context context) {
        context.stopService(new Intent(context, TService.class)); //ForegroundService
    }

    //RecyclerView.Adapter
    private void getInternalStorageFiles() {
        mArrayList = new ArrayList<>();
        String path = getApplicationContext().getFilesDir().getPath();
        String[] listOfFiles = getApplicationContext().getFilesDir().list();
        Log.d(TAG, "Files: " + new Gson().toJson(listOfFiles));
        if (listOfFiles != null) {
            for (String fileName : listOfFiles) {
                mArrayList.add(fileName+"/"+path);
            }
        }
    }
    private void playRecord(AlphabeticIndex.Record model) {
        mPlayer = new MediaPlayer();
        try {
            FileInputStream mInputStream = new FileInputStream(mArrayList.get(0)); //i = for loop
            mPlayer.setDataSource(mInputStream.getFD());
            mInputStream.close();
            mPlayer.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }
        mPlayer.start();
    }
    private void stopRecord() {
        if (mPlayer != null) {
            mPlayer.stop();
        }
    }
}